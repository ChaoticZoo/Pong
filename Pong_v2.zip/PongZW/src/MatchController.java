
/**
 * This class initializes the Pong game and obtains key information about screen
 * Dimension
 * 
 * Author: Zekun Wu
 * Date: June 26, 2019
 * Purpose: Pong project. To use in package: PongZW
 */

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class MatchController extends JFrame
{
	// Gets the display properties necessary for the game to scale itself to screen
	public static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	// Scaling factor is used to counteract the automatic scaling done by OS.
	public static int screenScale = Toolkit.getDefaultToolkit().getScreenResolution()
			* 100 / 96;

	//
	private static Paddles p;
	private static JPanel panel = new JPanel();
	public static int gameHeight;

	public MatchController(Container c)
	{
		// Sets the layout and adds the Pong game to Window.
		panel = new JPanel();

		p = new Paddles();
		p.setFocusable(true);

		panel.setLayout(new BorderLayout());
		panel.setBorder(new EmptyBorder(0, 5, 0, 5));

		panel.add(p);

		c.add(panel);
	}

	// Opens the window
	public static void main(String[] args)
	{
		JFrame w = new JFrame("Pong");
		w.setSize(screenSize.width, screenSize.height);

		Container c = w.getContentPane();
		new MatchController(c);

		w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		w.setResizable(false);
		w.setVisible(true);
	}
}
