
/**
 * This class outlines the Pong game object. It creates the game arena, paddles and ball
 * alone with dynamic variables that defines the physical properties of the moving parts.
 * 
 * Author: Zekun Wu
 * Date: June 26, 2019
 * Purpose: Pong project, to use in package: PongZW.
 * 
 */
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Paddles extends JPanel
		implements KeyListener, ActionListener
{
	private long startTime = System.currentTimeMillis();

	public final int REFRESH_TIME = 20;

	// In rare cases, users may want the whole mechanic to move faster or slower,
	// 160 is a constant and 1 is the scaling variable.
	public final int SPEED_SCALE = 160 * 20 * 1 / 1 / REFRESH_TIME;
	public int xLocation1, yLocation1, xLocation2, yLocation2, width, height;
	public int xLocation, yLocation, radius;
	private int iniX = MatchController.screenSize.width;
	private int iniY = MatchController.screenSize.height;

	// Counter-acts Windows OS scaling, which gives unreliable screenSize Dimensions.
	public int xSpeed = MatchController.screenSize.width
			* (MatchController.screenScale / 100) / SPEED_SCALE;

	public int ySpeed;

	private boolean goal;
	private boolean wStatus, sStatus, upStatus, downStatus;

	private int score1, score2;

	public Paddles()
	{
		reset();

		// By defaults, Re-renders component around every ~20 seconds. Changing this
		// value to <20 is not recommended as this program is compute-dependent.
		addKeyListener(this);
		Timer clock = new Timer(REFRESH_TIME, this);

		clock.start();
	}

	// These can be overridden when dimensions are specified.
	// @Override
	// public int getHeight()
	// {
	// return 1080;
	// }
	//
	// @Override
	// public int getWidth()
	// {
	// return 1920;
	// }

	// Calculates collisions and bounces, changes xSpeed and ySpeed.
	public void collision()
	{
		// Immediately pauses and reset the screen to prevent collision calculations,
		// which may result in unnecessary bounces caused by the new x and y locations.
		// For example, when paddle is moved to a position able to bounce the ball
		// after repaint.
		if (goal == true)
		{
			// Checks consistancy of x movement.
			// System.out.println(xLocation);

			// Pauses 2 seconds before resetting to show the location of the ball where
			// it passed the goal line.
			try
			{
				Thread.sleep(2000);
			} catch (InterruptedException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.reset();
		}

		// Check if the left edge of the ball passed the left goal line
		if (xLocation1 + width > xLocation
				- radius && xSpeed < 0)
		{
			// Check if there is a paddle there to catch it. Ball will not bounce if contact
			// point is more than 0.5 * radius away from the horizontal centerline.
			if (yLocation + 0.5 * radius >= yLocation1
					&& yLocation
							- 0.5 * radius <= yLocation1 + height - 1)
			{
				// Outputs travel distance and time.
				// System.out.println((xLocation1 + width) + ">"
				// + (xLocation - radius));
				// System.out.println(System.currentTimeMillis() - startTime);
				// startTime = System.currentTimeMillis();

				// if the paddle is not moving, ySpeed does not change, xSpeed reverses
				// and creates a normal deflection
				xSpeed = -xSpeed;

				// Send the ball at a random angle that is in the same direction as
				// the paddle movement, by giving a random ySpeed in the direction.
				if (wStatus)
					ySpeed = -(int) (Math.random() * this.getHeight()
							* (MatchController.screenScale / 100)
							/ 80);
				else if (sStatus)
					ySpeed = +(int) (Math.random() * this.getHeight()
							* (MatchController.screenScale / 100)
							/ 80);
			}

			else
			{
				// Once scored, re-render one more time, which paints the ball red,
				// and the second time will cause the delay because goal is set to true.
				if (goal != true)
				{
					score2++;
					goal = true;
				}
			}
		}

		if (xLocation2 < xLocation + radius && xSpeed > 0)
		{

			if (yLocation
					+ 0.5 * radius >= yLocation2
					&& yLocation
							- 0.5 * radius <= yLocation2 + height - 1)
			{
				System.out.println((xLocation1 + width) + ">"
						+ (xLocation - radius));
				System.out.println(System.currentTimeMillis() - startTime);

				startTime = System.currentTimeMillis();

				xSpeed = -xSpeed;
				if (upStatus)
					ySpeed = -(int) (Math.random() * this.getHeight()
							* (MatchController.screenScale / 100)
							/ (0.5 * SPEED_SCALE));
				else if (downStatus)
					ySpeed = +(int) (Math.random() * this.getHeight()
							* (MatchController.screenScale / 100)
							/ (0.5 * SPEED_SCALE));
			} else
			{
				if (goal != true)
				{
					score2++;
					goal = true;
				}
			}
		}

		// Top and Bottom deflections, test case found that in some resolutions the ball
		// wont move back within boundary line in time causing an infinite reversal in ySpeed
		if (yLocation - radius <= 0 && ySpeed < 0)
			ySpeed = -ySpeed;

		if (yLocation + radius >= this.getHeight() && ySpeed > 0)
			ySpeed = -ySpeed;
	}

	/*
	 * Determining the precise y-location of the ball :
	 * ySpeed / (yLocation - ?) = xSpeed / (xLocation - xLocation2) (goal line)
	 * ySpeed * (xLocation - xLocation 2) = xSpeed * (yLocation - ?)
	 * ySpeed * xLocation - ySpeed * xLocation2 - xSpeed * yLocation = -xSpeed * ?
	 * ? = (ySpeed * (xLocation2 - xLocation) + xSpeed * yLocation) / xSpeed
	 */
	public int getPreciseLocation(int dirSpeed, int dirLocation, int perpBoundary, int perpDirSpeed, int perpLocation)
	{
		return (int) ((float) (dirSpeed * (perpBoundary - perpLocation) +
				perpDirSpeed * dirLocation) / (float) (perpDirSpeed));
	}

	// Calculates the new location of the moving components by seeing if any of the keys
	// are currently being pressed.
	public void move()
	{
		if (wStatus)
		{
			if (yLocation1 > 0)
				yLocation1 -= this.getHeight()
						* (MatchController.screenScale / 100)
						/ SPEED_SCALE;

			// Paddles should remain static and create a normal deflection when
			// sitting at boundary.
			else
				wStatus = false;
		}
		if (sStatus)
		{
			if (yLocation1 + height <= this.getHeight())
				yLocation1 += this.getHeight()
						* (MatchController.screenScale / 100)
						/ SPEED_SCALE;
			else
				sStatus = false;
		}
		if (upStatus)
		{
			if (yLocation2 > 0)
				yLocation2 -= this.getHeight()
						* (MatchController.screenScale / 100)
						/ SPEED_SCALE;
			else
				upStatus = false;
		}
		if (downStatus)
		{
			if (yLocation > 0)
				yLocation2 += this.getHeight()
						* (MatchController.screenScale / 100)
						/ SPEED_SCALE;
			else
				downStatus = false;
		}

		// Moves the ball.
		xLocation += xSpeed;
		yLocation += ySpeed;
	}

	// Resets the fields to start a new match. Note that xSpeed is not being resetted
	// because the "loser" will get the ball first.
	public void reset()
	{
		width = iniX / 60;
		height = iniY / 8;
		xLocation1 = iniX / 40;
		yLocation1 = iniY / 2 - iniY / 20;
		xLocation2 = iniX - iniX / 40 - width;
		yLocation2 = iniY / 2 - iniY / 20;

		xLocation = iniX / 2;
		yLocation = iniY / 2;
		radius = iniX / 100;

		ySpeed = (int) (Math.random() * iniY
				* (MatchController.screenScale / 100) / 700);
		if ((int) (Math.random() + 0.5) >= 0.5)
			ySpeed = -ySpeed;

		goal = false;
	}

	@Override
	public void paintComponent(Graphics g)
	{
		//
		setBackground(Color.WHITE);
		super.paintComponent(g);
		g.setColor(Color.BLACK);

		// Two Paddles
		g.fillRect(xLocation1, yLocation1, width, height);
		g.fillRect(xLocation2, yLocation2, width, height);

		Graphics2D g2 = (Graphics2D) g;

		// Score Counter
		g2.setFont(new Font("Courier", Font.PLAIN, this.getWidth()
				/ 20));
		g2.drawString("" + score1, this.getWidth()
				/ 4, this.getHeight() / 5);
		g2.drawString("" + score2, this.getWidth() * 18
				/ 25, this.getHeight() / 5);

		// Translucent instructions.
		g2.setColor(new Color(0, 0, 0, 80));
		g2.setFont(new Font("Courier", Font.PLAIN, this.getWidth()
				/ 50));
		g2.drawString("Press SPACE To Restart Game", this.getWidth()
				/ 3, this.getHeight() * 9 / 10);
		g2.setFont(new Font("Courier", Font.PLAIN, this.getWidth()
				/ 75));
		g2.drawString("Press <W> and <S> move", this.getWidth()
				/ 9, this.getHeight() * 19 / 20);
		g2.drawString("Press <Arrow Up> and <Arrow down> to move", this.getWidth()
				* 3 / 5, this.getHeight() * 19 / 20);

		// Draws the arena with center line and goal lines.
		g2.setColor(Color.BLACK);
		BasicStroke s1 = new BasicStroke(this.getWidth() / 200);
		g2.setStroke(s1);
		g2.drawLine(xLocation1 + width, 0, xLocation1
				+ width, this.getHeight());
		g2.drawLine(xLocation2, 0, xLocation2, this.getHeight());

		float[] dash =
		{ 20.0f };

		BasicStroke s2 = new BasicStroke(this.getWidth()
				/ 300, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1.0f, dash, 2.0f);
		g2.setStroke(s2);
		g2.drawLine(width * 30, 0, width * 30, this.getHeight());

		// Draws the ball.
		if (goal == true)
			g.setColor(Color.RED);
		g.fillOval(xLocation - radius, yLocation - radius, radius * 2, radius
				* 2);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		// Move the ball and paddles by changing their location values, and calculate any
		// bounces or goals. Then repaints everything.
		move();
		collision();
		repaint();
	}

	// Once pressed, the pressed key's corresponding boolean variable will change to
	// true, and the move() method will perform the corresponding movements.
	@Override
	public void keyPressed(KeyEvent e)
	{
		// New key presses takes over priority over old ones, this is to account that
		// some players may release the old key only once new key is pressed.
		if (e.getKeyCode() == KeyEvent.VK_W)
		{
			// Prevents conflicting instructions.
			wStatus = true;
			sStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_S)
		{
			sStatus = true;
			wStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_UP)
		{
			upStatus = true;
			downStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN)
		{
			downStatus = true;
			upStatus = false;
		}
		// Resets the score, can also be used to test the initial throw angle.
		else if (e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			score1 = 0;
			score2 = 0;
			reset();
		}
		return;
	}

	// Since the paddles are moved by press and holding, this method does not have to
	// anything
	@Override
	public void keyTyped(KeyEvent e)
	{
		return;
	}

	// When key is released, the corresponding boolean variable is to changed to false
	// to prevent any further movements y move().b
	@Override
	public void keyReleased(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_W)
		{
			wStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_S)
		{
			sStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_UP)
		{
			upStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN)
		{
			downStatus = false;
		}

		return;
	}

}
