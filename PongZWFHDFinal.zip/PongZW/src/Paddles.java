import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Paddles extends JPanel
		implements KeyListener, ActionListener
{
	public int xLocation1, yLocation1, xLocation2, yLocation2, width, height;
	public int xLocation, yLocation, radius;
	private int iniX = 1920;
	private int iniY = 1080;
	public int xSpeed = 7;

	public int ySpeed;

	private boolean goal;
	private boolean wStatus, sStatus, upStatus, downStatus;

	private int score1, score2;

	public Paddles()
	{

		reset();

		addKeyListener(this);
		Timer clock = new Timer(0, this);

		clock.start();
	}

	@Override
	public int getWidth()
	{
		return 1904;
	}

	@Override
	public int getHeight()
	{
		return 1018;
	}

	@Override
	public void paintComponent(Graphics g)
	{
		// System.out.println(this.getWidth() + " " + this.getHeight());
		setBackground(Color.WHITE);
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		g.fillRect(xLocation1, yLocation1, width, height);
		g.fillRect(xLocation2, yLocation2, width, height);

		Graphics2D g2 = (Graphics2D) g;

		g2.setFont(new Font("Courier", Font.PLAIN, this.getWidth()
				/ 20));
		g2.drawString("" + score1, this.getWidth()
				/ 4, this.getHeight() / 5);
		g2.drawString("" + score2, this.getWidth() * 18
				/ 25, this.getHeight() / 5);

		g2.setColor(new Color(0, 0, 0, 80));
		g2.setFont(new Font("Courier", Font.PLAIN, this.getWidth()
				/ 50));
		g2.drawString("Press SPACE To Restart Game", this.getWidth()
				/ 3, this.getHeight() * 9 / 10);

		g2.setColor(Color.BLACK);
		BasicStroke s1 = new BasicStroke(this.getWidth() / 200);
		g2.setStroke(s1);
		g2.drawLine(xLocation1 + width, 0, xLocation1
				+ width, this.getHeight());
		g2.drawLine(xLocation2, 0, xLocation2, this.getHeight());

		float[] dash =
		{ 20.0f };

		BasicStroke s2 = new BasicStroke(this.getWidth()
				/ 300, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1.0f, dash, 2.0f);
		g2.setStroke(s2);
		g2.drawLine(width * 30, 0, width * 30, this.getHeight());

		if (goal == true)
			g.setColor(Color.RED);
		g.fillOval(xLocation - radius, yLocation - radius, radius * 2, radius
				* 2);
	}

	public void collision()
	{
		if (xLocation1 + width - 1 - this.getWidth() / 240 >= xLocation
				- radius)
		{
			if (yLocation + 0.5 * radius >= yLocation1
					&& yLocation - 0.5 * radius <= yLocation1 + height - 1)
			{
				xSpeed = -xSpeed;
				if (wStatus)
					ySpeed = -(int) (Math.random() * this.getHeight()
							/ 100);
				else if (sStatus)
					ySpeed = +(int) (Math.random() * this.getHeight()
							/ 100);
			}

			else
			{
				if (goal != true)
				{
					score2++;
					goal = true;
				} else
				{
					try
					{
						Thread.sleep(2000);
					} catch (InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					this.reset();
				}
			}
		}
		if (xLocation2 + this.getWidth() / 240 <= xLocation + radius)
		{
			if (yLocation + 0.5 * radius >= yLocation2
					&& yLocation - 0.5 * radius <= yLocation2 + height - 1)
			{
				xSpeed = -xSpeed;
				if (upStatus)
					ySpeed = -(int) (Math.random() * this.getHeight()
							/ 100);
				else if (downStatus)
					ySpeed = +(int) (Math.random() * this.getHeight()
							/ 100);
			} else

			{
				if (goal != true)
				{
					score1++;
					goal = true;
				} else
				{
					try
					{
						Thread.sleep(2000);
					} catch (InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					this.reset();
				}
			}
		}
		if (yLocation - radius <= 0)
			ySpeed = -ySpeed;

		if (yLocation + radius >= this.getHeight())
			ySpeed = -ySpeed;

	}

	public void reset()
	{
		width = iniX / 60;
		height = iniY / 8;
		xLocation1 = iniX / 40;
		yLocation1 = iniY / 2 - iniY / 20;
		xLocation2 = iniX - iniX / 40 - width;
		yLocation2 = iniY / 2 - iniY / 20;

		xLocation = iniX / 2;
		yLocation = iniY / 2;
		radius = iniX / 100;

		ySpeed = (int) (Math.random() * iniY / 600) + 1;

		goal = false;
	}

	@Override
	public void keyPressed(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_W)
		{
			wStatus = true;
			sStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_S)
		{
			sStatus = true;
			wStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_UP)
		{
			upStatus = true;
			downStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN)
		{
			downStatus = true;
			upStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			score1 = 0;
			score2 = 0;
			reset();
		}
		return;
	}

	public void move()
	{
		if (wStatus && yLocation1 >= 0)
			yLocation1 -= this.getHeight() / 200;
		if (sStatus && yLocation1 + height <= this.getHeight())
			yLocation1 += this.getHeight() / 200;
		if (upStatus && yLocation2 >= 0)
			yLocation2 -= this.getHeight() / 200;
		if (downStatus && yLocation2 + height <= this.getHeight())
			yLocation2 += this.getHeight() / 200;

		xLocation += xSpeed;
		yLocation += ySpeed;
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		move();
		collision();
		repaint();
	}

	@Override
	public void keyTyped(KeyEvent e)
	{

		return;
	}

	@Override
	public void keyReleased(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_W)
		{
			wStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_S)
		{
			sStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_UP)
		{
			upStatus = false;
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN)
		{
			downStatus = false;
		}

		return;
	}
}
