import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class MatchController extends JFrame
{
	public static int screenSize = Toolkit.getDefaultToolkit().getScreenResolution();
	private static Paddles p;
	private static JPanel panel = new JPanel();
	public static int gameHeight;

	public MatchController(Container c)
	{
		panel = new JPanel();

		p = new Paddles();
		p.setFocusable(true);

		panel.setLayout(new BorderLayout());
		panel.setBorder(new EmptyBorder(0, 5, 0, 5));

		panel.add(p);

		c.add(panel);
	}

	public static int compHeight()
	{
		return p.getHeight();
	}

	public static int compWidth()
	{
		return p.getWidth();
	}

	public static void main(String[] args)
	{
		JFrame w = new JFrame("Pong");
		w.setSize(1920, 1080);

		Container c = w.getContentPane();
		new MatchController(c);

		w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		w.setResizable(false);
		w.setVisible(true);
	}
}
